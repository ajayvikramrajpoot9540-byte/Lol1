package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.example.data.model.Product
import com.example.data.model.Shop
import com.example.data.repository.ApnaBazRepository
import com.example.ui.components.CameraVisualSearchEngine
import com.example.ui.components.LowestPriceFirstBadge
import com.example.ui.components.SearchBarCameraTrailingActions
import com.example.ui.components.VisualSearchStatusBanner
import com.example.ui.components.VisualSearchUiState
import com.example.ui.navigation.Screen
import com.example.ui.theme.BackgroundWarm
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldRating
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.OrangeLight
import com.example.ui.theme.OrangeSecondary
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.util.rememberCameraManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopDetailScreen(
    repository: ApnaBazRepository,
    shopId: String,
    onProductSelected: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val shops by repository.shops.collectAsState()
    val products by repository.products.collectAsState()
    val cartItems by repository.cartItems.collectAsState()
    val schedules by repository.shopSchedules.collectAsState()
    val context = LocalContext.current

    val shop = shops.find { it.id == shopId }
    val shopProducts = products.filter { it.shopId == shopId }
    val liveStatus = remember(schedules, shops, shopId) {
        repository.getShopLiveStatus(shopId)
    }

    var searchQuery by remember { mutableStateOf("") }
    var visualSearchState by remember { mutableStateOf<VisualSearchUiState>(VisualSearchUiState.Idle) }
    var lastCapturedSearchUri by remember { mutableStateOf<Uri?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun triggerVisualProductSearch(uri: Uri) {
        lastCapturedSearchUri = uri
        visualSearchState = VisualSearchUiState.Loading(uri)
        coroutineScope.launch {
            val state = CameraVisualSearchEngine.analyzeProductPhoto(
                context = context,
                imageUri = uri,
                catalogProducts = shopProducts
            )
            visualSearchState = state
            if (state is VisualSearchUiState.Success) {
                searchQuery = if (state.matchedProductsSortedByLowestPrice.isNotEmpty()) {
                    state.searchQuery
                } else {
                    state.detectedItemName
                }
            }
        }
    }

    val searchCameraManager = rememberCameraManager(
        onImageCaptured = { uri -> triggerVisualProductSearch(uri) },
        onError = { err -> visualSearchState = VisualSearchUiState.Error(lastCapturedSearchUri, err) }
    )

    val searchGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) triggerVisualProductSearch(uri)
    }

    val isSearchOrPhotoActive = searchQuery.isNotBlank() || visualSearchState is VisualSearchUiState.Success

    val filteredProducts = remember(shopProducts, searchQuery, visualSearchState) {
        CameraVisualSearchEngine.filterAndRankByLowestPrice(
            allProducts = shopProducts,
            query = searchQuery,
            visualState = visualSearchState
        )
    }

    val lowestPriceProductId = remember(filteredProducts, isSearchOrPhotoActive) {
        if (isSearchOrPhotoActive) {
            filteredProducts.firstOrNull { it.inStock }?.id ?: filteredProducts.firstOrNull()?.id
        } else {
            null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        com.example.ui.components.FlashDropCompactLogo(showText = false)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(shop?.name ?: "Shop Details", fontWeight = FontWeight.Bold, color = TextDark, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextDark)
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigate(Screen.Cart.route) }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = GreenPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            if (cartItems.isNotEmpty()) {
                val totalQty = cartItems.sumOf { it.quantity }
                val totalPrice = cartItems.sumOf { it.totalPrice }
                ExtendedCartPill(
                    count = totalQty,
                    total = totalPrice,
                    onClick = { onNavigate(Screen.Cart.route) }
                )
            }
        }
    ) { paddingValues ->
        if (shop == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Shop not found")
            }
        } else if (shop.id == "hemu_printing" || shop.category == "Printing Press") {
            HemuPrintingPressShopView(
                shop = shop,
                liveStatus = liveStatus,
                paddingValues = paddingValues,
                onUploadDocuments = {
                    if (liveStatus.isOpen) {
                        onNavigate(Screen.DocumentPrinting.route)
                    } else {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Shop is CLOSED (${liveStatus.nextOpeningTime}). Orders cannot be placed right now.")
                        }
                    }
                }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BackgroundWarm)
                    .padding(paddingValues),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 960.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                // Shop Banner & Info
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        AsyncImage(
                            model = shop.imageUrl,
                            contentDescription = shop.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(shop.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextDark, modifier = Modifier.weight(1f))
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (liveStatus.isOpen) GreenPrimary else Color(0xFFDC2626))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (liveStatus.isOpen) "OPEN" else "CLOSED",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = liveStatus.statusLabel,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (liveStatus.isOpen) GreenPrimary else Color(0xFFDC2626)
                            )
                            Text(
                                text = "Expected Delivery: ${liveStatus.expectedDeliveryEstimate}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (liveStatus.isOpen) GreenPrimary else Color(0xFFB45309)
                            )

                            if (!liveStatus.isOpen) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFFEF2F2))
                                        .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = "Shop is currently CLOSED. Next Opening Time: ${liveStatus.nextOpeningTime}. Add to Cart & Checkout are disabled until the shop opens.",
                                        fontSize = 11.sp,
                                        color = Color(0xFFB91C1C),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${shop.category} • ${shop.distance} from you", fontSize = 13.sp, color = OrangeSecondary, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(shop.description, fontSize = 13.sp, color = TextMuted, lineHeight = 18.sp)

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(shop.address, fontSize = 12.sp, color = TextDark)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Call, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(shop.phone, fontSize = 12.sp, color = TextMuted)
                            }
                        }
                    }
                }

                // In-Shop Search with Camera Photo Search
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            if (it.isBlank() && visualSearchState is VisualSearchUiState.Success) {
                                visualSearchState = VisualSearchUiState.Idle
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .testTag("shop_search_field"),
                        placeholder = { Text("Search by text, mic, or camera in ${shop.name}...", fontSize = 13.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GreenPrimary) },
                        trailingIcon = {
                            SearchBarCameraTrailingActions(
                                hasActiveQueryOrPhoto = searchQuery.isNotBlank() || visualSearchState !is VisualSearchUiState.Idle,
                                isAnalyzingPhoto = visualSearchState is VisualSearchUiState.Loading,
                                onClear = {
                                    searchQuery = ""
                                    visualSearchState = VisualSearchUiState.Idle
                                },
                                onLaunchCamera = { searchCameraManager.launchCamera() },
                                onPickFromGallery = {
                                    searchGalleryLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                onVoiceSearchResult = { spokenText ->
                                    searchQuery = spokenText
                                    visualSearchState = VisualSearchUiState.Idle
                                }
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = GreenPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        singleLine = true
                    )

                    VisualSearchStatusBanner(
                        state = visualSearchState,
                        onClear = {
                            visualSearchState = VisualSearchUiState.Idle
                            searchQuery = ""
                        },
                        onRetry = {
                            lastCapturedSearchUri?.let { triggerVisualProductSearch(it) }
                        }
                    )
                }

                if (shop.category.equals("Printing Press", ignoreCase = true) || shop.id == "hemu_printing") {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .clickable { onNavigate(Screen.DocumentPrinting.route) }
                                .testTag("shop_document_printing_cta"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = GreenLight),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GreenPrimary.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(GreenPrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Print,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Upload Documents for Printing",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = TextDark
                                    )
                                    Text(
                                        text = "PDF, JPG, PNG • A4 Black & White • ₹1.00/print (₹0.70 bulk)",
                                        fontSize = 11.sp,
                                        color = GreenPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Button(
                                    onClick = { onNavigate(Screen.DocumentPrinting.route) },
                                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Upload", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isSearchOrPhotoActive) {
                            "Matching Products – Least Price First (${filteredProducts.size})"
                        } else {
                            "Available Products (${filteredProducts.size})"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextDark,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                items(filteredProducts) { product ->
                    val inCart = cartItems.find { it.product.id == product.id }
                    val isLowestPriceHighlight = product.id == lowestPriceProductId

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 5.dp)
                            .clickable { onProductSelected(product.id) }
                            .testTag("shop_product_${product.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isLowestPriceHighlight) Color(0xFFF0FDF4) else Color.White
                        ),
                        border = if (isLowestPriceHighlight) androidx.compose.foundation.BorderStroke(1.5.dp, GreenPrimary) else null,
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isLowestPriceHighlight) 2.dp else 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = product.imageUrl,
                                contentDescription = product.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                if (isLowestPriceHighlight) {
                                    LowestPriceFirstBadge(modifier = Modifier.padding(bottom = 3.dp))
                                }
                                Text(product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextDark)
                                Text(product.unit, fontSize = 12.sp, color = TextMuted)
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("₹${product.price.toInt()}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = GreenPrimary)
                                    if (product.originalPrice > product.price) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("₹${product.originalPrice.toInt()}", fontSize = 12.sp, color = TextMuted, textDecoration = TextDecoration.LineThrough)
                                    }
                                }
                                if (!product.inStock) {
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 3.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFFFFEBEE))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("Out of Stock", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                                    }
                                }
                            }

                            if (!liveStatus.isOpen) {
                                Button(
                                    onClick = {},
                                    enabled = false,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        disabledContainerColor = Color(0xFFFEE2E2),
                                        disabledContentColor = Color(0xFFDC2626)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Shop Closed", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else if (!product.inStock) {
                                Button(
                                    onClick = {},
                                    enabled = false,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        disabledContainerColor = Color(0xFFF1F5F9),
                                        disabledContentColor = Color(0xFF94A3B8)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Out of Stock", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            } else if (inCart != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(GreenLight)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    IconButton(
                                        onClick = { repository.updateCartQuantity(product.id, -1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = GreenPrimary, modifier = Modifier.size(16.dp))
                                    }
                                    Text("${inCart.quantity}", fontWeight = FontWeight.Bold, color = GreenPrimary, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(
                                        onClick = { repository.updateCartQuantity(product.id, 1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", tint = GreenPrimary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        repository.addToCart(product)
                                        coroutineScope.launch { snackbarHostState.showSnackbar("Added ${product.name}") }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Add", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}


@Composable
fun HemuPrintingPressShopView(
    shop: Shop,
    liveStatus: com.example.data.model.ShopLiveStatus,
    paddingValues: PaddingValues,
    onUploadDocuments: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("Document Printing") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundWarm)
            .padding(paddingValues),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 960.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
        // 1. Hero Banner with Green Overlay (Screen 2)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                AsyncImage(
                    model = shop.imageUrl,
                    contentDescription = shop.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark gradient overlay for text legibility
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0x99000000))
                            )
                        )
                )

                // Green overlay badge on the right
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(GreenPrimary)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Column {
                        Text(
                            text = shop.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Quality Printing, Fast Service",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD1FAE5)
                        )
                    }
                }
            }
        }

        // 2. Rating & Distance info
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = GoldRating,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${shop.rating} (${shop.ratingCount})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextDark
                )
                Spacer(modifier = Modifier.width(16.dp))
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = shop.distance,
                    fontSize = 13.sp,
                    color = TextMuted
                )
            }
        }

        // 3. Document Printing & Photo Printing Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { selectedTab = "Document Printing" },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == "Document Printing") GreenPrimary else Color.White,
                        contentColor = if (selectedTab == "Document Printing") Color.White else TextDark
                    ),
                    border = if (selectedTab == "Document Printing") null else androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                ) {
                    Text(
                        text = "Document Printing",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = { selectedTab = "Photo Printing" },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == "Photo Printing") GreenPrimary else Color.White,
                        contentColor = if (selectedTab == "Photo Printing") Color.White else TextDark
                    ),
                    border = if (selectedTab == "Photo Printing") null else androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                ) {
                    Text(
                        text = "Photo Printing",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // 4. Our Services Section
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
                Text(
                    text = "Our Services",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ServiceItemCard(
                        title = "PDF Print",
                        icon = Icons.Default.Description,
                        modifier = Modifier.weight(1f),
                        onClick = onUploadDocuments
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ServiceItemCard(
                        title = "Image Print",
                        icon = Icons.Default.Image,
                        modifier = Modifier.weight(1f),
                        onClick = onUploadDocuments
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ServiceItemCard(
                        title = "Binding",
                        icon = Icons.Default.Book,
                        modifier = Modifier.weight(1f),
                        onClick = onUploadDocuments
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ServiceItemCard(
                        title = "Scanning",
                        icon = Icons.Default.CropFree,
                        modifier = Modifier.weight(1f),
                        onClick = onUploadDocuments
                    )
                }
            }
        }

        // 5. High Quality Prints Highlight Card (Yellowish / Amber with tag icon)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(OrangeSecondary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "High Quality Prints",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextDark
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Fast & Affordable",
                            fontSize = 13.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "A4 Size (Black & White Only)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F766E)
                        )
                    }
                }
            }
        }

        // 6. Upload Documents prominent green button (disabled when shop is closed)
        item {
            Spacer(modifier = Modifier.height(14.dp))
            if (!liveStatus.isOpen) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFEF2F2))
                        .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "CLOSED • Next Opening: ${liveStatus.nextOpeningTime} • Est. Delivery: ${liveStatus.expectedDeliveryEstimate}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB91C1C)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
            Button(
                onClick = onUploadDocuments,
                enabled = liveStatus.isOpen,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(52.dp)
                    .testTag("upload_documents_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GreenPrimary,
                    disabledContainerColor = Color(0xFFFEE2E2),
                    disabledContentColor = Color(0xFFDC2626)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = if (liveStatus.isOpen) Color.White else Color(0xFFDC2626),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (liveStatus.isOpen) "Upload Documents" else "Shop Closed (${liveStatus.nextOpeningTime})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (liveStatus.isOpen) Color.White else Color(0xFFDC2626)
                )
            }
        }
    }
}
}

@Composable
private fun ServiceItemCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFE8F5E9)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = GreenPrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextDark,
                maxLines = 1
            )
        }
    }
}
